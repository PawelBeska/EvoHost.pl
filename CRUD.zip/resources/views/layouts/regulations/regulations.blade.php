<div class="page-top" style=' background-image:url("{{URL::asset('assets/home/images/header_bg_2.jpg')}}")'>
    <!--  MESSAGES ABOVE HEADER IMAGE -->
    <div class="message">
        <div class="container">
            <div class="row">
                <div class="col-md-12 columns">
                    <div class="message-intro">
                        <span class="message-line"></span>
                        <p>Regulamin</p>
                        <span class="message-line"></span>
                    </div>
                    <h1 style="">Regulamin serwisu</h1>
                </div>
            </div>
        </div>
    </div>
    <!--  END OF MESSAGES ABOVE HEADER IMAGE -->
</div>
<div class="container">
<div class="row">
    <div class="col-lg-12">
        <div class="bs-component">
            <div class="jumbotron" style="">
                <h4>REGULAMIN.</h4>
                <hr class="my-4">
               <h5>Serwis evohost.pl jest darmowy.</h5>
               <h6>Możesz dodawać swoje pliki wideo bez limitu</h6>
               <h6>Możesz odtwarzać pliki wideo bez limitu</h6>
               <h5>Hostujemy pliki na następujących warunkach</h5>
                <h6>Po wrzucieniu pliku i pobraniu go przez serwer hostingujący, dostaniesz odnosnik do swojego pliku wideo. Możesz zamieścić odnosnik w iframe na swojej stronie, blogu lub udostępnić swój plik w sieciach społecznościowych.</h6>
                <h6>Możesz usunąć swój plik wideo w każdej chwili</h6>
                <h5>Nie możesz</h5>
                <h6>Używać serwisu do celów zabrionionych przez prawo</h6>
                <h6>Używać programów do oglądania plików wideo.</h6>
                <h5>Nie możesz wgrywać plików gdy:</h5>
                <h6>Pliki naruszają prawa autorskie dowolnego podmiotu.</h6>
                    <h6>Pliki są niezgodne z prawem i / lub naruszają jakiekolwiek prawa.</h6>
                    <h5>Informacje</h5>
                    <h6>Nie ponosimy odpowiedzialności za utracone lub uszkodzone łącza, pliki, lub błędnie umieszczone adresy URL plików. Użytkownik jest odpowiedzialny za śledzenie tych informacji.</h6>
                    <h6>Wszystkie pliki są chronione prawami autorskimi ich właścicieli. Serwis evohost.pl nie ponosi odpowiedzialności za treść jakichkolwiek przesłanych plików, ani nie jest powiązany z żadnymi podmiotami, które mogą być reprezentowane w przesłanych plikach.</h6>

            </div>
        </div>
    </div>
</div>
</div>

