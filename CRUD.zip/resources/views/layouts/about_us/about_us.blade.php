<div class="page-top" style=' background-image:url("{{URL::asset('assets/home/images/header_bg_2.jpg')}}")'>
    <!--  MESSAGES ABOVE HEADER IMAGE -->
    <div class="message">
        <div class="container">
            <div class="row">
                <div class="col-md-12 columns">
                    <div class="message-intro">
                        <span class="message-line"></span>
                        <p>O nas</p>
                        <span class="message-line"></span>
                    </div>
                    <h1 style="">Zarejestruj się już dziś</h1>
                </div>
            </div>
        </div>
    </div>
    <!--  END OF MESSAGES ABOVE HEADER IMAGE -->
</div>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="bs-component">
                <div class="jumbotron" style="">
                    <h1 class="display-4">O nas</h1>
					<hr class="my-4">
                    <h5>Jesteśmy firmą hostingująca pliki wiedo online.<Br>
					Udostępniamy własny odtwarzacz na potrzeby oglądania plików wideo w internecie!<Br>
					Nakładamy jak największy nacisk na to, aby nasz portał był ekonomiczny jak i wydajny względem dzisiejszych wymogów,<br>
					dotyczących budowania stron internetowych o podobnej infrastrukurze. Chcemy, aby nasze projekty były wykonane <Br>
					starannie i bezpiecznie, tak, aby każdy użytkownik, który korzysta z naszych serwisów, nie musiał się obawiać, że<Br>
					"jego dane mogą wycieknąć do osoby trzeciej". Tym jesteśmy, jesteśmy firmą, która tworzy projekty pod ludzi, a nie dla zysku.<br>
					Dla nas liczy się użytkownik, a nie gotówka w kieszeni. <br><Br>
					
					Pozdrawia zespół EvoHost.pl
	
                </div>
                @yield('footer')
            </div>
        </div>
    </div>
</div>