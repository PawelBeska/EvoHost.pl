<div class="page-top" style=' background-image:url("{{URL::asset('assets/home/images/header_bg_2.jpg')}}")'>
    <!--  MESSAGES ABOVE HEADER IMAGE -->
    <div class="message">
        <div class="container">
            <div class="row">
                <div class="col-md-12 columns">
                    <div class="message-intro">
                        <span class="message-line"></span>
                        <p>Rejestracja</p>
                        <span class="message-line"></span>
                    </div>
                    <h1 style="">Zarejestruj się już dziś</h1>
                </div>
            </div>
        </div>
    </div>
    <!--  END OF MESSAGES ABOVE HEADER IMAGE -->
</div>
<div class="container">
<div class="row">
    <div class="col-lg-12">
        <div class="bs-component">
            <div class="jumbotron" style="">
                <h1 class="display-4">kontakt</h1>
                <p class="lead">kontakt z administracją.</p>
                <hr class="my-4">
                <h5>Współpraca:</h5>
                <h6>wspolpraca@evohost.pl</h6>
                <h5>Zgłoszenia:</h5>
                <h6>zgloszenia@evohost.pl</h6>
                <h5>Inne:</h5>
                <h6>kontakt@evohost.pl</h6>
            </div>
            @yield('footer')
        </div>
    </div>
</div>
</div>