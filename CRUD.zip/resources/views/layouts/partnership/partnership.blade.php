<div class="page-top" style=' background-image:url("{{URL::asset('assets/home/images/header_bg_2.jpg')}}")'>
    <!--  MESSAGES ABOVE HEADER IMAGE -->
    <div class="message">
        <div class="container">
            <div class="row">
                <div class="col-md-12 columns">
                    <div class="message-intro">
                        <span class="message-line"></span>
                        <p>Program partnerski</p>
                        <span class="message-line"></span>
                    </div>
                    <h1 style="">OFERTA WSPÓŁPRACY</h1>
                </div>
            </div>
        </div>
    </div>
    <!--  END OF MESSAGES ABOVE HEADER IMAGE -->
</div>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="bs-component">
                <div class="jumbotron" style="">
                    <h4>PROGRAM PARTNERSKI.</h4>
                    <hr class="my-4">
					<h5>Nasza firma przygotowała dla każdego użytkownika jak i firmy program partnerski.<h3><Br>

                            <h5>Partnerzy:</h5>
                            <p>
                               - 18% z zarobionych reklam online.<br>
                                - Możlliwość własnych reklam w odtwarzaczu.<br>
                                - Możliwość stworzenia odtwarzacza z własnym logiem strony www.<br>
                                - Pomoc web developerów w prowadzeniu API.<br>
                                - Odtwarzacze premium.<br>
                                - Autorski panel zarządzania swoim partnerstwem.<br>
                                - I wiele więcej.<br>
                            </p><br><br>

                            <h5>Użytkownicy :</h5>
                            <p>- Zarabiaj na wrzuconych filmach aż do 8% za wyświetlone reklamy!<br>
                            - Wypłacaj pieniądze raz na miesiąc.<br>
                            - Ciekawe programy dla użytkowników.<br>
                            - Wiele konkursów i róznych bonusów.<br>
                                - I wiele więcej! <br></p><br>
					<h5>Jeżeli jesteś zainteresowany programem partnerskim, zapraszamy do kontaktu na : <b>wspolpraca@evohost.pl</b></h3>
                        <h7>*Jeżeli jesteś użytkownikiem do programu partnerskiego dla użytkowników przystąpisz w panelu klienta!</h7>
                </div>
            </div>
        </div>
    </div>
</div>

