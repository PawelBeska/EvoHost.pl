<head>

    <title>eVohost.pl - Twój bezpłatny hosting filmów.</title>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-129753787-1');
    </script>
    <link href="https://fonts.googleapis.com/css?family=Staatliches" rel="stylesheet">

    <style type="text/css">
        body{
            background-color: #1e2730;
        }
        .logo {
            position: absolute;
            top: 40%;
            left: 50%;
            -moz-transform: translateX(-50%) translateY(-50%);
            -webkit-transform: translateX(-50%) translateY(-50%);
            transform: translateX(-50%) translateY(-50%);
        }
        .container {
            position: absolute;
            top: 50%;
            left: 50%;
            -moz-transform: translateX(-50%) translateY(-50%);
            -webkit-transform: translateX(-50%) translateY(-50%);
            transform: translateX(-50%) translateY(-50%);
        }
        p{
            color:white;
            font-family: 'Staatliches', cursive;
            font-size: 30px;
            text-shadow: 0 1px 0 rgb(0, 0, 0);
        }
    </style>

</head>
<body>

<div>
    <img class="logo" src="{{URL::asset('assets/home/images/logo.png')}}" alt="">
    <div class="container">

        <p>Plik nie istnieje lub został on usunięty!</p>
    </div>
</div>
</body>

