<section class="vc_rows wpb_rows vc_rows-fluid vc-row-full-width">
    <div class="row">
        <div class="wpb_column col-sm-12">
            <div class="wpb_wrapper">
                <div class="page-top page-880">
                    <div class="message container">
                        <div class="message-intro">
                            <span class="message-line"></span>
                            <p>Hosting na jaki czekałeś</p>
                            <span class="message-line"></span>
                        </div>
                        <h1>
                            <span id="js-rotating">WYDAJNE SERWERY, NIELIMITOWANY DYSK, ANONIMOWOŚĆ, NOWOCZESNA ARCHITEKTURA SERWERÓW, TWÓJ PIERWSZY... PRAWDZIWY HOSTING</span></h1>
                        <a href="{{route('login')}}" class="small radius btn scroll">Zaloguj się, aby dodać swoje pliki!</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<section class="vc_rows wpb_rows vc_rows-fluid vc_custom_1445314919990 vc-row-full-width">
    <div class="container">
        <div class="row">
            <div class="wpb_column col-sm-12">
                <div class="wpb_wrapper">
                    <div class="wpb_text_column wpb_content_element  vc_custom_1445314945384">
                        <div class="wpb_wrapper">
                            <h2 style="text-align: center;"><strong>NAJWIĘCEJ MOŻLIWOŚCI</strong></h2>
                            <p style="text-align: center;">Jesteśmy otwarci na wszelkie propozycje współpracy, masz pytania? Skontaktuj się na wspolpraca@evohost.pl!</p>

                        </div>
                    </div>
                </div>
            </div>
            <div class="wpb_column col-sm-4 vc_custom_1473736800511">
                <div class="wpb_wrapper wow fadeInLeft" data-wow-delay="0.2s">
                    <div class="about-us-links">
                        <i class="fa fa-database"></i>    <h3>Przestrzenne dyski</h3>
                        <p>Dysponujemy dużą pojemnością na twoje filmy!</p>
                    </div>


                    <div class="about-us-links">
                        <i class="fas fa-server"></i>   <h3>Serwery</h3>
                        <p>Posiadamy szybkie niezawodne serwery.</p>
                    </div>

                </div></div>
            <div class="wpb_column col-sm-4 vc_custom_1473736805335">
                <div class="wpb_wrapper wow zoomIn" data-wow-delay="0.4s">
                    <div class="about-us-links">
                        <i class="fas fa-shield-alt"></i>   <h3>Zabezpieczenia</h3>
                        <p>Chronimy twoje pliki w jak najlepszy sposób, aby twoje dane były bezpieczne.</p>
                    </div>


                    <div class="about-us-links">
                        <i class="fas fa-users"></i>   <h3>Program partnerski</h3>
                        <p>Ciekawy i nowoczesny program partnerski dla firm jak i użytkowników.</p>
                    </div>

                </div></div><div class="last wpb_column col-sm-4 vc_custom_1473736814503"><div class="wpb_wrapper wow fadeInRight" data-wow-delay="0.6s">
                    <div class="about-us-links">
                        <i class="fa fa-code"></i>    <h3>Developer API</h3>
                        <p>Przyjazny system do zarządzania przez programistów.</p>
                    </div>


                    <div class="about-us-links">
                        <i class="fa fa-rocket"></i>    <h3>Kontakt 24/7</h3>
                        <p>Błyskawiczne biuro obsługi klienta.</p>
                    </div>

                </div></div></div></div></section>
<section class="vc_rows wpb_rows vc_rows-fluid vc_custom_1445327064253 vc-row-full-width"><div class="container"><div class="row"><div class="wpb_column col-sm-12"><div class="wpb_wrapper">
                    <div class="wpb_text_column wpb_content_element ">
                        <div class="wpb_wrapper">
                            <div class="circle"><i class="fa fa-heart"><b>a</b></i></div>

                        </div>
                    </div>
                    <div class="wpb_text_column wpb_content_element ">
                        <div class="wpb_wrapper">
                            <h2 class="white" style="text-align: center;"><strong>SPRAWDŹ NAS I TY! </strong></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>