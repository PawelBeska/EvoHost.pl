<div class="page-top" style=' background-image:url("{{URL::asset('assets/home/images/header_bg_2.jpg')}}")'>
    <!--  MESSAGES ABOVE HEADER IMAGE -->
    <div class="message">
        <div class="container">
            <div class="row">
                <div class="col-md-12 columns">
                    <div class="message-intro">
                        <span class="message-line"></span>
                        <p>Upload Zdalny</p>
                        <span class="message-line"></span>
                    </div>
                    <h1 style="">ZDALNE PRZESYŁANIE PLIKÓW</h1>
                </div>
            </div>
        </div>
    </div>
    <!--  END OF MESSAGES ABOVE HEADER IMAGE -->
</div>
<div class="container" style="    margin-bottom: 60px;">
<div class="row">
    <div class="col-lg-12">
                    {!! Form::open(['class'=>'remote','url'=>route('remote_post')]) !!}
                    <div class="panel-body">
                        <div id="errors"></div>
                        <div class="form-group">
                            {!! Form::label('sources','Źródło: (Jeden link na jedną linijkę)') !!}
                            {!! Form::textarea('sources',null,['class'=>'form-control','rows'=>5]) !!}
                        </div>
                        <button id="singlebutton" name="singlebutton" class="col-md-12 btn btn-primary">Wyślij</button>

<p>Obsługiwane playery: https://fileone.tv, https://www.bitporno.com lub pliki mp4</p>
                    </div>{!! Form::close() !!}

        </div>
    </div>
</div>