<div class="page-top" style=' background-image:url("{{URL::asset('assets/home/images/header_bg_2.jpg')}}")'>
    <!--  MESSAGES ABOVE HEADER IMAGE -->
    <div class="message">
        <div class="container">
            <div class="row">
                <div class="col-md-12 columns">
                    <div class="message-intro">
                        <span class="message-line"></span>
                        <p>Współpraca</p>
                        <span class="message-line"></span>
                    </div>
                    <h1 style="">Podstawowe informacje na temat współpracy</h1>
                </div>
            </div>
        </div>
    </div>
    <!--  END OF MESSAGES ABOVE HEADER IMAGE -->
</div>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="bs-component">
                <div class="jumbotron" style="">
                    <h1 class="display-4">Współpraca</h1>
					<hr class="my-4">
                    <h5>Jeżeli jesteś zainteresowany współpraca z firmą EVOHOST, zapraszamy
					do kontaktu na adres wspolpraca@evohost.pl.<h5>
					<h5>Przedstaw nam ciekawy pomysł, a my postaramy się jak najszybciej przedstawić naszą ofertę!</h5>
                </div>
                @yield('footer')
            </div>
        </div>
    </div>
</div>