<footer>
    <div class="container">
        <div class="row">
            <div class="footerlinks">
                <div class="col-md-4 col-sm-6 columns">
                    <div id="text-3" class="widget widget_text"><h2>Serwis</h2>
                        <div class="textwidget"><ul>
                                <li><a href="{{route('regulations')}}">Regulamin</a></li>
                                <li><a href="{{route('dmca')}}">Zasady korzystania</a></li>
                                <li><a href="{{route('contact')}}">Kontakt</a></li>
                                <li><a href="{{route('partnership')}}">Program partnerski</a></li>
                            </ul></div>
                    </div>
                </div><!-- end col-lg-3 -->
                <div class="col-md-4 col-sm-6 columns">
                    <div id="text-4" class="widget widget_text"><h2>Dla firm i użytkowników</h2>
                        <div class="textwidget"><ul>
                                <li><a href="{{route('about_us')}}">O nas</a></li>
                                <li><a href="{{route('cooperation')}}">Współpraca</a></li>
                                <li><a href="{{route('advertisement')}}">Reklama</a></li>
                            </ul></div>
                    </div>
                </div><!-- end col-lg-3 -->
                <div class="col-md-4 col-sm-6 columns">
                    <div id="text-5" class="widget widget_text"><h2>Inne</h2>			<div class="textwidget"><ul>
                            
                            </ul></div>
                    </div>
                </div><!-- end col-lg-3 -->
            </div>
            </div>

            <p class="copyright">LICENCJA <a href="{{route('index')}}" target="_blank">eVoHost.pl</a>, WSZELKIE PRAWA ZASTRZEŻONE</p>
    </div>
</footer>