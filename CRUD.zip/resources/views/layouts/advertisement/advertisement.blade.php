<div class="page-top" style=' background-image:url("{{URL::asset('assets/home/images/header_bg_2.jpg')}}")'>
    <!--  MESSAGES ABOVE HEADER IMAGE -->
    <div class="message">
        <div class="container">
            <div class="row">
                <div class="col-md-12 columns">
                    <div class="message-intro">
                        <span class="message-line"></span>
                        <p>Reklama</p>
                        <span class="message-line"></span>
                    </div>
                    <h1 style="">Zareklamuj się u nas!</h1>
                </div>
            </div>
        </div>
    </div>
    <!--  END OF MESSAGES ABOVE HEADER IMAGE -->
</div>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="bs-component">
                <div class="jumbotron" style="">
                    <h1 class="display-4">REKLAMA</h1>
                    <hr class="my-4">
                    <h5>Jesteś zainteresowany reklamą w naszym odtwarzaczu?<h5>
					<h5>Chciałbyś, aby znajdowała się tam twoja reklama?<h5>
					<h5>Nic prostrzego!<h5>
					<h5>Napisz do nas na <i>reklama@evohost.pl</i>, i przedstaw nam swoją ofertę!<h5>
					<h5>A my odpiszemy jak najszybciej możemy i przedstawimy ofertę!</h5><br><br>
					
					<h4>Gotowy? Zaczynajmy!</h4>
                </div>
                @yield('footer')
            </div>
        </div>
    </div>
</div>