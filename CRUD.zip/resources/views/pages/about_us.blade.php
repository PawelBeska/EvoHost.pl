@extends('master')

@section('header')
    @include('layouts.global.header.header')
@stop
@section('body')
    @include('layouts.about_us.about_us')
@stop
@section('footer')
    @include('layouts.global.footer.footer')
@stop
