<!DOCTYPE html>

<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <title>eVohost.pl - Twój bezpłatny hosting filmów.</title>
    <link rel='dns-prefetch' href='//maps.googleapis.com' />
    <link rel='dns-prefetch' href='//fonts.googleapis.com' />
    <link rel='dns-prefetch' href='//s.w.org' />
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>

    <link rel='stylesheet' id='bootstrap-css'  href='{{URL::asset('assets/home/css/bootstrap.css')}}' type='text/css' media='all' />
    <link rel='stylesheet' id='owl-car-css'  href='{{URL::asset('assets/home/css/owl.carousel.css')}}' type='text/css' media='all' />
    <link rel='stylesheet' id='owl-theme-css'  href='{{URL::asset('assets/home/css/owl.theme.css')}}' type='text/css' media='all' />
    <link rel='stylesheet' id='owltransitions-css'  href='{{URL::asset('assets/home/css/owl.transitions.css')}}' type='text/css' media='all' />
    <link rel='stylesheet' id='animate-css'  href='{{URL::asset('assets/home/css/animate.min.css')}}' type='text/css' media='all' />
    <link rel='stylesheet' id='tablesaw-css'  href='{{URL::asset('assets/home/css/tablesaw.stackonly.css')}}' type='text/css' media='all' />
    <link rel='stylesheet' id='slicknav-css'  href='{{URL::asset('assets/home/css/slicknav.css')}}' type='text/css' media='all' />
    <link rel='stylesheet' id='morphext-css'  href='{{URL::asset('assets/home/css/morphext.css')}}' type='text/css' media='all' />
    <link rel='stylesheet' id='normalize-css'  href='{{URL::asset('assets/home/css/normalize.css')}}' type='text/css' media='all' />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
   <link rel='stylesheet' id='style-css'  href='{{URL::asset('assets/home/style.css')}}' type='text/css' media='all' />
    <link rel='stylesheet' id='js_composer_front-css'  href='{{URL::asset('assets/home/css/js_composer.min.css')}}' type='text/css' media='all' />
    <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>

    <script type='text/javascript' src='{{URL::asset('assets/home/js/jquery/jquery-migrate.min.js')}}'></script>
    <script type='text/javascript' src='{{URL::asset('assets/home/js/vendor/owl.carousel.min.js')}}'></script>
    <meta name="csrf-token" content="6wi7L58XFAYSKdKYn4oQA7bvxDReg58aYdjfIw2m" />
    <style type="text/css">.wpcf7-response-output{margin: 0;}
        .comparison .pricing-table li {
            line-height: 54px;
            padding: 0;
        }
        .comparison .pricing-table.alter.features li {
            display: table;
            width: 100%;
            padding: 0 0.9375em;
            height: 55px;
        }
        .comparison .has-tip {
            display: table-cell;
            line-height: 20px;
            vertical-align: middle;
        }

        .home-kb-search .form-control{ color: #333; }
        .last .about-us-links{ border-right:none; }
        .page-template-template-whmcs{
            padding-top: 42px;
        }
        .whmcs-page .top{
            background-image:url({{URL::asset('assets/home/images/header_bg_2.jpg')}});
        }
    </style>
    <link rel="icon" href="{{URL::asset('favicon.ico')}}" sizes="32x32" />
    <link rel="icon" href="{{URL::asset('favicon.ico')}}" sizes="192x192" />
    <link rel="apple-touch-icon-precomposed" href="{{URL::asset('favicon.ico')}}" />
    <meta name="msapplication-TileImage" content="{{URL::asset('favicon.ico')}}" />
    <style type="text/css" data-type="vc_shortcodes-custom-css">
        .vc_custom_1445314919990{    padding-top: 75px !important;
            padding-bottom: 75px !important;
            background-color: #ffffff !important;}
        .vc_custom_1445331043598{padding-top: 50px !important;padding-bottom: 50px !important;background-color: #222d3a !important;}
        .vc_custom_1484711920023{padding-top: 50px !important;padding-bottom: 50px !important;}
        .vc_custom_1445327064253{padding-top: 50px !important;padding-bottom: 50px !important;background-color: #222d3a !important;}
        .vc_custom_1445315736712{padding-top: 50px !important;}
        .vc_custom_1473736800511{padding-right: 0px !important;padding-left: 0px !important;}
        .vc_custom_1473736805335{padding-right: 0px !important;padding-left: 0px !important;}
        .vc_custom_1473736814503{padding-right: 0px !important;padding-left: 0px !important;}
        .vc_custom_1445314945384{margin-bottom: 60px !important;}
        .vc_custom_1445315139615{margin-bottom: 50px !important;}
        .vc_custom_1445315491387{margin-bottom: 10px !important;}</style><noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>
    <link rel="stylesheet" id="fullcolor-css" href="" type="text/css" media="all">
    <link rel="stylesheet" id="fullcolor-css2" href="" type="text/css" media="all">
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	 <script>(function(e,t,n){var r=e.querySelectorAll("html")[0];r.className=r.className.replace(/(^|\s)no-js(\s|$)/,"$1js$2")})(document,window,0);</script>
	 
	 <script>
	 
	 var drop = $("input");
drop
  .on("dragenter", function(e) {
    $(".drop").css({
      border: "4px dashed #09f",
      background: "rgba(0, 153, 255, .05)"
    });
    $(".cont").css({
      color: "#09f"
    });
  })
  .on("dragleave dragend mouseout drop", function(e) {
    $(".drop").css({
      border: "3px dashed #DADFE3",
      background: "transparent"
    });
    $(".cont").css({
      color: "#8E99A5"
    });
  });

function handleFileSelect(evt) {
  var files = evt.target.files; // FileList object

  // Loop through the FileList and render image files as thumbnails.
  for (var i = 0, f; (f = files[i]); i++) {
    // Only process image files.
    if (!f.type.match("image.*")) {
      continue;
    }

    var reader = new FileReader();

    // Closure to capture the file information.
    reader.onload = (function(theFile) {
      return function(e) {
        // Render thumbnail.
        var span = document.createElement("span");
        span.innerHTML = [
          '<img class="thumb" src="',
          e.target.result,
          '" title="',
          escape(theFile.name),
          '"/>'
        ].join("");
        document.getElementById("list").insertBefore(span, null);
      };
    })(f);

    // Read in the image file as a data URL.
    reader.readAsDataURL(f);
  }
}

$("#files").change(handleFileSelect);


</script>


 </head>

<body class="page page-id-1216 page-template page-template-page-templates page-template-template-canvas page-template-page-templatestemplate-canvas-php wpb-js-composer js-comp-ver-4.12.1 vc_responsive">

@yield('header')


@yield('body')
@yield('footer')
<a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>

<script type='text/javascript' src='{{URL::asset('assets/home/js/vendor/modernizr.js')}}'></script>
<script type='text/javascript' src='{{URL::asset('assets/home/js/vendor/hoverIntent.js')}}'></script>
<script type='text/javascript' src='{{URL::asset('assets/home/js/vendor/morphext.min.js')}}'></script>
<script type='text/javascript' src='{{URL::asset('assets/home/js/vendor/superfish.min.js')}}'></script>
<script type='text/javascript' src='{{URL::asset('assets/home/js/vendor/wow.min.js')}}'></script>
<script type='text/javascript' src='{{URL::asset('assets/home/js/vendor/jquery.animateNumber.min.js')}}'></script>
<script type='text/javascript' src='{{URL::asset('assets/home/js/vendor/waypoints.min.js')}}'></script>
<script type='text/javascript' src='{{URL::asset('assets/home/js/vendor/jquery.slicknav.min.js')}}'></script>
<script type='text/javascript' src='{{URL::asset('assets/home/js/vendor/retina.min.js')}}'></script>
<script type='text/javascript' src='{{URL::asset('assets/home/js/vendor/masonry.pkgd.min.js')}}'></script>
<script type='text/javascript' src='{{URL::asset('assets/home/js/vendor/jquery-ui.min.js')}}'></script>
<script type='text/javascript' src='{{URL::asset('assets/home/js/custom.js')}}'></script>
<script type='text/javascript' src='{{URL::asset('assets/home/js/js_composer_front.min.js')}}'></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>


</body>
</html>