<?php

namespace App\Http\Controllers;

use HTMLMin\HTMLMin\Facades\HTMLMin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Redirect;

class HomeController extends Controller
{


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        return HTMLMin::blade(view('pages.index'));
    }
    public function regulations()
    {
        return HTMLMin::blade(view('pages.regulations'));
    }
    public function dmca()
    {
        return HTMLMin::blade(view('pages.dmca'));
    }
    public function contact()
    {
        return HTMLMin::blade(view('pages.contact'));
    }
    public function partnership()
    {
        return HTMLMin::blade(view('pages.partnership'));
    }
    public function about_us()
    {
        return HTMLMin::blade(view('pages.about_us'));
    }
    public function cooperation()
    {
        return HTMLMin::blade(view('pages.cooperation'));
    }
    public function advertisement()
    { 
        return HTMLMin::blade(view('pages.advertisement'));
    }
}
