<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use HTMLMin\HTMLMin\Facades\HTMLMin;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;

class CheckForMaintenanceMode
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $ip = $_SERVER['REMOTE_ADDR'];
        $username = Auth::user();
        $maintenace = true;

        if($maintenace) {
            if (Auth::guest()) {
                return $next($request);
            } elseif (Auth::user()->HasPermission('admin')) {
                return $next($request);
            } elseif (maintenace_whitelist::Where('ip', $ip)->OrWhere('username', $username)->count()) {
                return $next($request);
            } else {
                return Response::make(view('pages.maintenace'));
            }
        }else{
            return $next($request);
        }
    }
}