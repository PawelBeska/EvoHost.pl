$(function(){
	$('.long-press').first().longPress();
});